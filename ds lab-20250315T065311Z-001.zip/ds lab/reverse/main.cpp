#include <iostream>

using namespace std;
#define n 10
int main()
{
    string a[n];
    string b[n];

    int ne=5;
    for(int i=0; i<=ne;i++){
    cout<<"Enter the Array:";
    cin>>a[i];
    }
    for(int i=ne; i>=0;i--){
        b[i]=a[i];
    cout<<b[i]<<"\t";
    }
return 0;

}
